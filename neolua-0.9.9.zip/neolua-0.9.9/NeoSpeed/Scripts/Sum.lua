﻿
local sum = 0;

for i = 0, 1000, 1 do
	sum = sum + i;
end;

return sum;