﻿local a = 0;
repeat
	a = a + 1;
until a >= 10;
return a;