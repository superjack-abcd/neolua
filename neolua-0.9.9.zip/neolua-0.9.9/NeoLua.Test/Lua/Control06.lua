﻿local a = 0;
for i = 1,10,1 do
	a = a + i;
end;
return a;