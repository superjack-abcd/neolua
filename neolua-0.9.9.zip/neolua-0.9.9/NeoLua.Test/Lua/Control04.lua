﻿local a = 0;
while a < 10 do
	a = a + 1;
	if a == 4 then
		break;
	end;
end;
return a;