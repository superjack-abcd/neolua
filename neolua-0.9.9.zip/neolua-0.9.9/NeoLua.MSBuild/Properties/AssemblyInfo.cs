﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NeoLua.MSBuild")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("bcd0312a-1eea-4826-9b01-6b84cfb3dde1")]
