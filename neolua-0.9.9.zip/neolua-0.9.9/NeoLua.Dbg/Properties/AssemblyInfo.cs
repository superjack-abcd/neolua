﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NeoLua.Dbg")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("23c0f353-cf3d-4b7d-92e6-000bc840bc5e")]
