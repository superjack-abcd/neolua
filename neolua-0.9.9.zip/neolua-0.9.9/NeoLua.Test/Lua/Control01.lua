﻿local a = 2;
if a < 2 then
	a = 1;
elseif a > 2 then
	a = 2;
else
	a = 3;
end;
return a;