﻿local CompareMeClass = clr.LuaDLR.Test.ControlStructures.CompareMe;

local a = CompareMeClass:ctor(1);
return a + 3;