﻿for i = 0, 1000, 1 do
	test(i);
end;
