﻿local a = 0;
while a < 10 do
	a = a + 1;
end;
return a;