﻿
test = {};

function test.add(a, b)
    return a + b;
end;

return 1;