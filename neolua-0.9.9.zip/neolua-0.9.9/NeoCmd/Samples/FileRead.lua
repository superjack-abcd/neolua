﻿do (sw = clr.System.IO.StreamReader([[C:\Projects\NeoLua\trunk\NeoCmd\Samples\FileRead.lua]]))
  error("test");
  print(sw:ReadToEnd());
end;